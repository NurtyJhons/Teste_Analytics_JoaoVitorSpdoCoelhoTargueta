# Como falado no "readme", instale as seguintes bibliotecas no terminal com o comando: 
# install.packages("tidyverse")
library(tidyverse) # Eu vou precisar dessa biblioteca instalada pra instalar o dplyr e também usar o "distinct"

# install.packages("lubridate")
library(lubridate) # Preciso dessa biblioteca pra converter strings em objetos do tipo data

# install.packages("dplyr")
library(dplyr) # É necessário essa biblioteca pra usar a função "distinct"

# Criando um data frame de vendas com pelo menos 50 registros:
df_sujo <- data.frame(
  ID = c(1, 2, 2, 3, 4, 4, 5, 6, 7, 7, 8, 9, 10, 11, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50),  # Duplicatas nos IDs 2, 4 e 7
  Data = as.Date(c("2023-01-09", "2023-02-15", "2023-02-15", "2023-03-10", "2023-03-10", "2023-03-10", NA, "2023-05-05", "2023-06-20", "2023-06-23", "2023-06-26", "2023-06-16", "2023-06-29", "2023-06-30", "2023-07-09", "2023-07-11", "2023-07-14", "2023-07-15", "2023-07-20", "2023-07-24", "2023-07-28", "2023-07-30", NA, "2023-08-04", "2023-08-10", "2023-08-12", "2023-08-13", "2023-08-19", "2023-08-20", "2023-08-21", "2023-08-29", "2023-09-03", "2023-09-22", "2023-10-26", "2023-10-29", "2023-11-01", "2023-11-04", "2023-11-14", "2023-11-16", "2023-11-20", "2023-12-01", "2023-12-02", "2023-12-04", "2023-12-07", "2023-12-14", "2023-12-15", "2023-12-17", "2023-12-19", "2023-12-20", "2023-12-24")),  # Valor faltante na data
  Produto = c("Camiseta", "Calça", "Calça", "Tênis", "Boné", "Boné", "Relógio", "Relógio", NA, "Relógio", NA, "Camiseta", "Camiseta", "Tênis",  "Boné", "Colar", "Colar", "Colar", "Relógio", "Boné", "Relógio", "Camiseta", "Camiseta", "Relógio", "Boné", "Relógio", "Calça", "Camiseta", "Colar", "Relógio", "Camiseta", "Calça", "Calça", "Relógio", "Colar", "Boné", "Relógio", "Calça", "Calça", "Relógio", "Colar", "Calça", "Calça", "Calça", "Camiseta", "Colar", "Tênis", "Colar"," Camiseta", "Calça"),  # Valor faltante no produto
  Categoria = c("Roupas", "Roupas", "Roupas", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Roupas", "Roupas", "Roupas", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Roupas", "Roupas", "Acessórios", "Acessórios", "Acessórios", "Roupas", "Roupas", "Acessórios", "Acessórios", "Roupas", "Roupas", "Roupas", "Acessórios", "Acessórios", "Acessórios", "Acessórios", "Roupas", "Roupas", "Acessórios", "Acessórios", "Roupas", "Roupas", "Roupas", "Roupas", "Acessórios", "Acessórios", "Acessórios", "Roupas", "Roupas"),
  Quantidade = c(2, 3, 3, 1, 2, 2, 5, 1, 1, 1, 3, 2, 1, 1, 2, 3, 2, 2, 3, 2, 3, 4, 2, 1, 1, 2, 3, 4, 2, 3, 4, 1, 1, 2, 4, 1, 1, 2, 3, 2, 3, 2, 3, 4, 3, 4, 2, 4, 3, 4),
  Preco = c(29.99, 59.99, 79.99, 19.99, NA, 99.99, NA, 59.99, 59.99, 79.99, 59.99, 79.99, 19.99, 19.99, 99.99, 19.99, 59.99, 59.99, 19.99, 99.99, 59.99, 79.99, 19.99, 89,99, 89,99, 49,99, 59,99, 99,99,29,99, 59,99, 99,99,29,99, 19.99, 19.99, 99.99, 59.99, 79.99, 79,99, 89,99)  # Valor faltante no preço
)

# Removendo as duplicatas
df_semilimpo <- distinct(df_sujo, ID, .keep_all = TRUE)

# Verificando quais são os valores faltantes
colSums(is.na(df_semilimpo))

# Removendo linhas com algum valor faltante
df_limpo <- na.omit(df_semilimpo)

# Visualizando o dataset limpo agora
View(df_limpo)

# Salvando o dataset como arquivo csv
write.csv(df_limpo, file = "data_clean.csv", row.names = FALSE)

# Vou recarregar o dataset limpo
df_limpo <- read.csv("data_clean.csv")

# E agora, usando o pacote dplyr e a função "mutate" eu vou adicionar uma nova 
# coluna chamada "total_vendas" a partir da Quantidade * Preco
df_pronto <- df_limpo %>%
  mutate(total_vendas = Quantidade * Preco)

# Agora eu pego o total de vendas de cada produto, somar todos que possuem o mesmo
# nome de produto com eles mesmos, e conferir o total de vendas de cada produto:
vendas_por_produto <- df_pronto %>%
  group_by(Produto) %>%
  summarize(total_vendas = sum(total_vendas))

# Ordenando o dataframe vendas_por_produto de forma decrescente pelo total de vendas:
vendas_por_produto <- vendas_por_produto %>%
  arrange(desc(total_vendas))

# Exibindo o primeiro resultado (ou seja, qual foi a maior venda) pois está de 
# forma decrescente:
o_produto_mais_vendido <- vendas_por_produto[1, ]
print(o_produto_mais_vendido)
# O produto com maior venda então foi a Calça.

# Agora vou criar um novo dataframe "vendas_por_mes" que agrupa os dados por mês
# e calcula o total de vendas
vendas_por_mes <- df_pronto %>%
  mutate(mes = floor_date(Data, "month")) %>%
  group_by(mes) %>%
  summarize(total_vendas = sum(Quantidade * Preco))

# O R deu erro de que não estava identificando as variáveis da coluna "Data" 
# como datas, então esse código aqui ajusta isso:
df_pronto <- df_pronto %>%
  mutate(Data = as.Date(Data, format = "%Y-%m-%d"))

# E agora funciona:
vendas_por_mes <- df_pronto %>%
  mutate(mes = floor_date(Data, "month")) %>%
  group_by(mes) %>%
  summarize(total_vendas = sum(Quantidade * Preco))

# Para criar gráficos de linha, é preciso instalar a biblioteca ggplot2 no terminal:
# install.packages("ggplot2")

# Carregando a biblioteca:
library(ggplot2)

# Criando o gráfico de linha
ggplot(vendas_por_mes, aes(x = mes, y = total_vendas)) +
  geom_line() +
  labs(title = "Evolução das Vendas Mensais",
       x = "Mês",
       y = "Total de Vendas")

# Salvando o dataset como arquivo csv para importar como SQL na parte 2 do exercicio
write.csv(df_pronto, file = "data_pronto.csv", row.names = FALSE)